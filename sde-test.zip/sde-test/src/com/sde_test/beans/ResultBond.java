package com.sde_test.beans;

public class ResultBond {
	
	String corporateBondId;
	String governmentBondId;
	String spreadToBenchMark;
	double benchMark;
	public double getBenchMark() {
		return benchMark;
	}
	public void setBenchMark(double benchMark) {
		this.benchMark = benchMark;
	}
	public String getCorporateBondId() {
		return corporateBondId;
	}
	public void setCorporateBondId(String corporateBondId) {
		this.corporateBondId = corporateBondId;
	}
	public String getGovernmentBondId() {
		return governmentBondId;
	}
	public void setGovernmentBondId(String governmentBondId) {
		this.governmentBondId = governmentBondId;
	}
	public String getSpreadToBenchMark() {
		return spreadToBenchMark;
	}
	public void setSpreadToBenchMark(String spreadToBenchMark) {
		this.spreadToBenchMark = spreadToBenchMark;
	}
	
}
