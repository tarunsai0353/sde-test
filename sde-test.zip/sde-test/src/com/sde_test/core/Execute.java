package com.sde_test.core;

import java.io.*;
import java.util.*;
import java.util.Map.Entry;

import org.json.simple.*;
import org.json.simple.parser.*;

import com.sde_test.beans.CorporateBond;
import com.sde_test.beans.GovernmentBond;
import com.sde_test.beans.ResultBond;
public class Execute {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JSONParser parser = new JSONParser();
		List<CorporateBond> corpbondList = new ArrayList<CorporateBond>();
		List<GovernmentBond> govtbondList = new ArrayList<GovernmentBond>();
		List<ResultBond> resultBondList = new ArrayList<ResultBond>();

		try {
			Object resultObject = parser.parse(new FileReader("input_file.json"));
			JSONObject dataObject = (JSONObject)resultObject;
			JSONArray data = (JSONArray)dataObject.get("data");
			Iterator iterator = data.iterator();
			while (iterator.hasNext()) {
				JSONObject jsonObject = (JSONObject)iterator.next();
				String id = (String)jsonObject.get("id");
				if(jsonObject != null && id != null 
						&& id.startsWith("c")) {
					CorporateBond corpBond = new CorporateBond();
					corpBond.setId(id);
					String trimTenor = (String)jsonObject.get("tenor");
					if(trimTenor != null)
						trimTenor = trimTenor.replace(" years", "");
					corpBond.setTenor(Double.parseDouble(trimTenor));
					String trimYield = (String)jsonObject.get("yield");
					if(trimYield != null)
					{
						trimYield = trimYield.replace("%", "");
						corpBond.setYield(Double.parseDouble(trimYield));
					}
					corpBond.setType((String)jsonObject.get("type"));
					corpBond.setMaturity((Long)jsonObject.get("amount_outstanding"));
					corpbondList.add(corpBond);
				} else if(id.startsWith("g")) {
					GovernmentBond govtBond = new GovernmentBond();
					govtBond.setId(id);
					String trimTenor = (String)jsonObject.get("tenor");
					if(trimTenor != null)
						trimTenor = trimTenor.replace(" years", "");
					govtBond.setTenor(Double.parseDouble(trimTenor));
					String trimYield = (String)jsonObject.get("yield");
					if(trimYield != null)
						trimYield = trimYield.replace("%", "");
					//govtBond.setTenor(Long.parseLong(trimTenor));
					govtBond.setYield(Double.parseDouble(trimYield));
					govtBond.setType((String)jsonObject.get("type"));
					govtBond.setMaturity((Long)jsonObject.get("amount_outstanding"));
					govtbondList.add(govtBond);
				}
			}

			//Logic Starts here
			System.out.println("Printing non empty bonds :::");
			for (CorporateBond corporateBond : corpbondList) {
				if(corporateBond.getId()!=null
						&& corporateBond.getTenor() > 0
						&& corporateBond.getMaturity() > 0
						&& corporateBond.getType()!=null
						&& corporateBond.getYield() > 0) {
					System.out.println(corporateBond.getId());
					for (GovernmentBond governmentBond : govtbondList) {
						ResultBond resBond = new ResultBond();
						resBond.setCorporateBondId(corporateBond.getId());
						resBond.setGovernmentBondId(governmentBond.getId());

						double bpsvalue = 0;
						if(corporateBond.getYield() > governmentBond.getYield())
							bpsvalue = (corporateBond.getYield()-governmentBond.getYield())*100;
						else
							bpsvalue = (governmentBond.getYield() - corporateBond.getYield())*100; 
						resBond.setSpreadToBenchMark(bpsvalue+" bps");

						double benchMarkValue = 0;
						if(corporateBond.getTenor() > governmentBond.getTenor())
							benchMarkValue = corporateBond.getTenor() - governmentBond.getTenor();
						else
							benchMarkValue = governmentBond.getTenor() - corporateBond.getTenor();
						resBond.setBenchMark(benchMarkValue);
						resultBondList.add(resBond);
					}
				}
			}
			System.out.println("**************************************************************************");
			System.out.println("Printing overall bonds :::");
			//bestBenchmark
			double minVal = resultBondList.get(0).getBenchMark();
			String str = "";
			HashMap<String, List<Double>> finalMap = new HashMap<String, List<Double>>(); 
			for (CorporateBond cb : corpbondList) {
				List<Double> d = new ArrayList<Double>();
				for (ResultBond resultBond : resultBondList) {
					if(cb.getId().equalsIgnoreCase(resultBond.getCorporateBondId())) {
						if(minVal > resultBond.getBenchMark())
							minVal = resultBond.getBenchMark();
						System.out.println(resultBond.getCorporateBondId() 
								+"\t"+ resultBond.getGovernmentBondId()
								+"\t"+ resultBond.getBenchMark()
								+"\t"+ resultBond.getSpreadToBenchMark());
						d.add(resultBond.getBenchMark());
					}
				}
				finalMap.put(cb.getId(), d);
				if(d.size() > 0)
					System.out.println("-----------------------------------------------------------------");
			}
			System.out.println("**************************************************************************");
			System.out.println("Printing bonds with values:::");
			HashMap<String, Double> finalValues = new HashMap<String, Double>();
			for (Entry<String, List<Double>> obj : finalMap.entrySet()) {
				System.out.println(obj.getKey()+" ----- "+obj.getValue());
				if(obj.getValue()!= null && obj.getValue().size() > 0) {
					List<Double> smallD = obj.getValue();
					double minD = smallD.get(0);
					for (Double d : smallD) {
						if(d < minD)
							minD = d;
					}
					finalValues.put(obj.getKey(), minD);
					//System.out.println(obj.getKey()+" "+minD);				
				}
			}
			System.out.println("**************************************************************************");
			System.out.println("Printing final calculated bonds :::");
			JSONArray jsonArray = new JSONArray();
			for (Entry<String, Double> values : finalValues.entrySet()) {
				for (ResultBond resultBond : resultBondList) {
					if(resultBond.getCorporateBondId().equalsIgnoreCase(values.getKey())
							&& resultBond.getBenchMark() == values.getValue()) {
						System.out.println(resultBond.getCorporateBondId() 
								+"\t"+ resultBond.getGovernmentBondId()
								+"\t"+ resultBond.getBenchMark()
								+"\t"+ resultBond.getSpreadToBenchMark());
						JSONObject jsonObject = new JSONObject();
						jsonObject.put("corporate_bond_id", resultBond.getCorporateBondId());
						jsonObject.put("government_bond_id", resultBond.getGovernmentBondId());
						jsonObject.put("spread_to_benchmark", resultBond.getSpreadToBenchMark());
						jsonArray.add(jsonObject);
					}
				}
			}
			// Writing data output json file
			JSONObject jsObject = new JSONObject();
			jsObject.put("data", jsonArray);
			FileWriter file = new FileWriter("output_file.json");
			file.write(jsObject.toJSONString());
			file.close();
		} catch(Exception e) {
			System.out.println("Error occured please try gain later");
		}

	}

}
