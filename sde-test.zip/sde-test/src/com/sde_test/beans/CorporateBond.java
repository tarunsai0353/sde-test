package com.sde_test.beans;

public class CorporateBond {
	String id;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getTenor() {
		return tenor;
	}
	public void setTenor(double tenor) {
		this.tenor = tenor;
	}
	public double getYield() {
		return yield;
	}
	public void setYield(double yield) {
		this.yield = yield;
	}
	public long getMaturity() {
		return maturity;
	}
	public void setMaturity(long maturity) {
		this.maturity = maturity;
	}
	String type;
	double tenor;
	double yield;
	long maturity;
	ResultBond resultBond;
	public ResultBond getResultBond() {
		return resultBond;
	}
	public void setResultBond(ResultBond resultBond) {
		this.resultBond = resultBond;
	}
}
